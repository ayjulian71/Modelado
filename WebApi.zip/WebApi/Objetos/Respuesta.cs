﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Objetos
{
    public class RespuestaBase<T>
    {
        public int CodigoOperacion { get; set; }
        public string Mensage { get; set; }
        public T Resultado { get; set; }
    }
}
