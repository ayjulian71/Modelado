﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
namespace WebApi.Objetos
{
    public class Funciones
    {
        public RespuestaBase<double> Parametros { get; set; }
      

        public Funciones()
        {
            Parametros = new RespuestaBase<double>()
            {
                CodigoOperacion = 400,
                Mensage = "Respuesta Operacion:"
            };
        }

        //Enumeracines

        private enum Operacion
        {
            Add = 1,
            Rest = 2,
            Mult = 3,
            Div = 4
        }


        public RespuestaBase<double> Adicionar(string numeros)
       
        {
            var resp = new RespuestaBase<double>();
            var sum = CalcularOperacion(numeros, Operacion.Add);
            resp.CodigoOperacion = Parametros.CodigoOperacion;
            resp.Resultado = sum;
            resp.Mensage = Parametros.Mensage  + " para Suma" ;

            return resp;
         
        }

        // Operaciones 
        public RespuestaBase<double> Resta(string numeros)

        {
            var resp = new RespuestaBase<double>();
            var sum = CalcularOperacion(numeros, Operacion.Rest);
            resp.CodigoOperacion = Parametros.CodigoOperacion;
            resp.Resultado = sum;
            resp.Mensage = Parametros.Mensage + " para Resta";

            return resp;

        }

        public RespuestaBase<double> Multiplar(string numeros)

        {
            var resp = new RespuestaBase<double>();
            var ope = CalcularOperacion(numeros, Operacion.Mult);
            resp.CodigoOperacion = Parametros.CodigoOperacion;
            resp.Resultado = ope;
            resp.Mensage = Parametros.Mensage + " para Multiplicar";

            return resp;

        }

        public RespuestaBase<double> Dividir(string numeros)

        {
            var resp = new RespuestaBase<double>();
            var sum = CalcularOperacion(numeros, Operacion.Div);
            resp.CodigoOperacion = Parametros.CodigoOperacion;
            resp.Resultado = sum;
            resp.Mensage = Parametros.Mensage + " para Dividir";

            return resp;

        }

        //Metodos Clase
        private double CalcularOperacion(string nums, Operacion operation)
        {
            var value = 0D;
            var numbers = new List<double>();

            numbers = Transformacion(nums);
            if (Parametros.CodigoOperacion == 400)
            {
                switch (operation)
                {
                    case Operacion.Add:
                        {
                            foreach (var i in numbers) value = value + i;
                            break;
                        }
                    case Operacion.Rest:
                        {
                            value = numbers[0];
                            for (var i = 1; i < numbers.Count; ++i) value = value - numbers[i];
                            break;
                        }
                    case Operacion.Mult:
                        {
                            value = 1;
                            foreach (var i in numbers) value = value * i;
                            break;
                        }
                    case Operacion.Div:
                        {
                            value = ValidarDivision(numbers);
                            break;
                        }
                }
            }
            else
            {
                value = 0;
            }

            return value;
        }

        //Validaciones
        public bool ValidarNumero(string strvalor)
        {
            bool bollrep = false;

            foreach (string num in strvalor.Split('/'))

            {
                Regex expRe1 = new Regex(@"^[+-]?\d+(\.\d+)?$");
                if (expRe1.IsMatch(num))
                {
                    bollrep = true;
                }
                else
                {
                    bollrep = false;
                }
            }
        

            return bollrep;
        }

        private List<double> Transformacion(string numbers)
        {
            var result = new List<double>();
         
            bool boolResu = false;
            boolResu = ValidarNumero(Convert.ToString(numbers));
          
            if (boolResu == false)
            {
                Parametros.CodigoOperacion = 310;
                Parametros.Mensage = "Parametros inavalidos";
            }
            else
            {
                if (!string.IsNullOrWhiteSpace(numbers))
                {
                    var splitter = numbers.Split('/');

                    if (splitter.Length > 0)
                    {
                        for (var i = 0; i < splitter.Length; ++i)
                        {
                            var isEmpty = string.IsNullOrWhiteSpace(splitter[i].ToString());
                            var isNumber = float.TryParse(splitter[i], out float n);

                            if (!isEmpty && isNumber)
                            {
                                result.Add(Convert.ToDouble(splitter[i]));
                            }
                            else
                            {
                                Parametros.CodigoOperacion = 310;
                                Parametros.Mensage = "Parametros invalidos";

                                break;
                            }
                        }
                    }
                    else
                    {
                        Parametros.CodigoOperacion = 311;
                        Parametros.Mensage = "Sin parametros";
                    }
                }
                else
                {
                    Parametros.CodigoOperacion = 312;
                    Parametros.Mensage = "Parametros no encontrados";
                }
            }
            

            return result;
        }

        private double ValidarDivision(List<double> numbers)
        {
            var value = numbers[0];

            for (var i = 1; i < numbers.Count; ++i)
            {
                if (numbers[i] != 0)
                {
                    value = value / numbers[i];
                }
                else
                {
                    Parametros.CodigoOperacion = 500;
                    Parametros.Mensage = "Tipos flotantes";
                    value = 0;

                    break;
                }
            }

            return value;
        }
    }
}
