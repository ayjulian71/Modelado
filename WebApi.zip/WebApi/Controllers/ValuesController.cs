﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApi.Objetos;
namespace WebApi.Controllers
{
    [Route("api/[controller]")]
      public class ValuesController : Controller
    {
     
        // GET api/values
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "Para ejecutar la calculadora digite(api/values/Operacion[add/Rest/Div/Mul]/Valores(n/n/n" };
        }

       
        // GET api/add/values/Add
        [HttpGet("Add/{*nums}")]
        public ActionResult Add([Bind] string nums)
        {

          
            var oper = new Funciones();
            var result = oper.Adicionar(nums);

            return Ok(result);
        }

        // GET api/add/values/Add
        [HttpGet("Rest/{*nums}")]
        public ActionResult Rets([Bind] string nums)
        {


            var oper = new Funciones();
            var result = oper.Resta(nums);

            return Ok(result);
        }

        // GET api/add/values/Add
        [HttpGet("Mult/{*nums}")]
        public ActionResult Mult([Bind] string nums)
        {


            var oper = new Funciones();
            var result = oper.Multiplar(nums);

            return Ok(result);
        }

        // GET api/add/values/Add
        [HttpGet("Div/{*nums}")]
        public ActionResult Div([Bind] string nums)
        {
            var oper = new Funciones();
            var result = oper.Dividir(nums);
            return Ok(result);
        }
        
    }
}
